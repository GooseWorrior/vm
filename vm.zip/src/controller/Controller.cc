#include "Controller.h"

#include <ncurses.h>
#include <string>

using std::string;

namespace CS246E {
Controller::Controller(){};
}  // namespace CS246E

#include "PlainView.h"

namespace CS246E {
PlainView::PlainView(VM* vm) : View{vm} {}
void PlainView::initialize() {}
void PlainView::update() {}
PlainView::~PlainView() {}
}  // namespace CS246E
